/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicios;

/**
 *
 * @author mati
 */
public class Prog13 {
    public static void main (String args[]){
        int Nota1=10;
        int Nota2=7;
        int media;
        System.out.println("Programación ");
        System.out.println(Nota1);
        System.out.println(Nota2);
        System.out.println("Media " + (Nota1+Nota2)/2);
        
        
    }
    
}
