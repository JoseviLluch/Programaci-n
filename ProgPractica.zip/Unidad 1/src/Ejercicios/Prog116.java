/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicios;

/**
 *
 * @author mati
 */
public class Prog116 {
    public enum DiaSemana{ lunes, martes, miercoles, jueves, viernes }
    
    public enum Calificaciones{ Insuficiente, Suficiente, Bien, Notable, Excelente }
    
    public enum Colores{ rojo, amarillo, azul }
    
    public enum NotasMusicales{ Do, Re, Mi, Fa, Sol, La, Si }
    
    public static void main(String[]args){
        System.out.println(DiaSemana.lunes);
    }
}  
    

