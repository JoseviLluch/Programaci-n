/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicios;

/**
 *
 * @author mati
 */
public class Prog12 {
    public static void main (String args[]){
        System.out.print("José Vicente ");
        System.out.print("Lluch ");
        System.out.print("Manzaneda \n ");
        System.out.print("12/12/1993 ");
    } 
    
}
