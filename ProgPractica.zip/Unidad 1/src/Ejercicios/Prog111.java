/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicios;

/**
 *
 * @author mati
 */
public class Prog111 {
    public static void main (String[]args){
        int a=15;
        int b=25;
        int lvertical=a;
        int lhorizontal=b;
        int perimetro=((a*2)+(b*2));
        int area=((a*a)+(b*b));
        System.out.println("La longitud de los lados son " + lvertical + " " + "y "+ lhorizontal);
        System.out.println("El perimetro es " + perimetro);
        System.out.println("El area es " + area);
        
               
    }
    
    
}
